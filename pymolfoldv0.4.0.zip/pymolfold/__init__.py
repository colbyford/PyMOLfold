# Standard library imports
from __future__ import absolute_import
from __future__ import print_function
import os
import tempfile
import sys
import shutil
import atexit
from pathlib import Path
import subprocess
import logging
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass
from urllib.parse import urljoin

# Third-party imports
import torch
import requests
from pymol.Qt import QtWidgets, QtGui
from pymol.Qt.utils import loadUi
from pymol import cmd
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class FoldingResult:
    """Container for protein folding results"""
    success: bool
    message: str
    output_path: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class UniProtClient:
    """Client for interacting with UniProt API"""
    BASE_URL = "https://rest.uniprot.org/uniprotkb/"

    @staticmethod
    def get_sequence(uniprot_id: str) -> Tuple[bool, str]:
        """Fetch protein sequence from UniProt"""
        try:
            url = urljoin(UniProtClient.BASE_URL, f"{uniprot_id}.json")
            response = requests.get(url)
            
            if response.status_code == 200:
                data = response.json()
                sequence = data["sequence"]["value"]
                return True, sequence
            else:
                return False, f"Error fetching sequence: {response.status_code}"
                
        except Exception as e:
            return False, f"Error accessing UniProt: {str(e)}"

class PyMOLfoldPlugin:
    """PyMOLfold plugin main class"""
    dialog = None
    
    @staticmethod
    def run_plugin_gui():
        """Initialize and show the plugin GUI"""
        if PyMOLfoldPlugin.dialog is None:
            PyMOLfoldPlugin.dialog = PyMOLfoldPlugin.create_dialog()
        PyMOLfoldPlugin.dialog.show()

    @staticmethod
    def fetch_uniprot_sequence(uniprot_id: str) -> Tuple[bool, str]:
        """Fetch sequence from UniProt"""
        return UniProtClient.get_sequence(uniprot_id)

    @staticmethod
    def fold_esm(model_name: str, aa_sequence: str, temperature: float = 0.7, 
                 num_steps: int = 8, token: str = "") -> FoldingResult:
        """Execute ESM-based protein structure prediction"""
        try:
            from esm.sdk import client
            from esm.sdk.api import ESMProtein, GenerationConfig
        except ModuleNotFoundError as e:
            return FoldingResult(False, f"ESM module not found: {str(e)}")

        try:
            # Initialize ESM client with provided token
            model = client(
                model=model_name,
                url="https://forge.evolutionaryscale.ai",
                token=token
            )

            # Configure prediction parameters
            config = GenerationConfig(
                track="structure",
                num_steps=num_steps,
                temperature=temperature,
            )
            
            # Generate prediction and convert to PDB format
            prediction = model.generate(ESMProtein(sequence=aa_sequence), config)
            pdb_string = prediction.to_protein_chain().to_pdb_string()

            # Save to temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdb", prefix="pymolfold_") as temp_pdb:
                temp_pdb.write(pdb_string.encode())
                return FoldingResult(True, "Structure prediction successful", temp_pdb.name)

        except Exception as e:
            return FoldingResult(False, f"Error in ESM folding: {str(e)}")

    @staticmethod
    def fold_chai(aa_sequence: str, ligand: Optional[str] = None, 
                  ligand_type: Optional[str] = None, num_trunk_recycles: int = 3,
                  num_diffn_timesteps: int = 200, seed: int = 1337) -> FoldingResult:
        """Execute Chai-based protein structure prediction"""
        try:
            from chai_lab.chai1 import run_inference
        except ImportError as e:
            return FoldingResult(False, f"Required module not found: {str(e)}")

        temp_dir = None
        try:
            # Create temporary directory
            temp_dir = tempfile.mkdtemp(prefix="pymolfold_")
            base_dir = Path(temp_dir)
            input_dir = base_dir / "input"
            output_dir = base_dir / "output"
            input_dir.mkdir(exist_ok=True)
            output_dir.mkdir(exist_ok=True)

            # Prepare FASTA content
            if ligand and ligand_type:
                fasta_content = (
                    f">protein|name=chain_A\n{aa_sequence.strip()}\n"
                    f">ligand|name=chain_B\n{ligand.strip()}\n"
                )
            else:
                fasta_content = f">protein|name=chain_A\n{aa_sequence.strip()}\n"

            # Write FASTA file
            fasta_path = input_dir / "sequence.fasta"
            fasta_path.write_text(fasta_content)

            device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
            
            candidates = run_inference(
                fasta_file=fasta_path,
                output_dir=output_dir,
                num_trunk_recycles=num_trunk_recycles,
                num_diffn_timesteps=num_diffn_timesteps,
                seed=seed,
                device=device,
                use_esm_embeddings=True
            )

            if not candidates.cif_paths:
                return FoldingResult(False, "No structure files were generated")

            # Create a new temporary file for the result
            with tempfile.NamedTemporaryFile(delete=False, suffix=".cif", prefix="pymolfold_result_") as temp_file:
                shutil.copy2(str(candidates.cif_paths[0]), temp_file.name)
                return FoldingResult(True, "Structure prediction successful", temp_file.name)

        except Exception as e:
            return FoldingResult(False, f"Error in Chai folding: {str(e)}")
        finally:
            # Clean up the working directory
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up temporary directory: {str(e)}")

    @staticmethod
    def fold_boltz(aa_sequence: str, ligand: Optional[str] = None,
                   ligand_type: Optional[str] = None, use_msa_server: bool = False,
                   recycling_steps: int = 3, sampling_steps: int = 200) -> FoldingResult:
        """Execute Boltz-based protein structure prediction"""
        try:
            import boltz
        except ModuleNotFoundError as e:
            return FoldingResult(False, f"Required module not found: {str(e)}")

        temp_dir = None
        try:
            # Create temporary directory that won't be immediately deleted
            temp_dir = tempfile.mkdtemp(prefix="pymolfold_")
            base_dir = Path(temp_dir)
            input_dir = base_dir / "input"
            output_dir = base_dir / "output"
            input_dir.mkdir(exist_ok=True)
            output_dir.mkdir(exist_ok=True)

            # Prepare FASTA content
            fasta_content = f">A|protein|empty\n{aa_sequence}\n"
            if ligand and ligand_type:
                fasta_content += f">B|{ligand_type}|\n{ligand}\n"

            # Write FASTA file
            fasta_path = input_dir / "sequence.fasta"
            fasta_path.write_text(fasta_content)
            
            device = "gpu" if torch.cuda.is_available() else "cpu"
            
            boltz_cmd = Path(sys.executable).parent / 'boltz'
            cmd = [
                str(boltz_cmd),
                "predict",
                str(fasta_path),
                "--out_dir", str(output_dir),
                "--accelerator", device,
                "--output_format", "pdb",
                "--recycling_steps", str(recycling_steps),
                "--sampling_steps", str(sampling_steps)
            ]
            
            if use_msa_server:
                cmd.append("--use_msa_server")
            
            # Run prediction
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            # Check output and copy to a new location
            output_path = output_dir / "boltz_results_sequence" / "predictions" / "sequence" / "sequence_model_0.pdb"
            if not output_path.exists():
                return FoldingResult(False, f"Output file not found at: {output_path}")
            
            # Create a new temporary file for the result
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdb", prefix="pymolfold_result_") as temp_file:
                shutil.copy2(str(output_path), temp_file.name)
                return FoldingResult(True, "Structure prediction successful", temp_file.name)

        except Exception as e:
            return FoldingResult(False, f"Error in Boltz folding: {str(e)}")
        finally:
            # Clean up the working directory
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up temporary directory: {str(e)}")
           
    @staticmethod
    def apply_alphafold_colors(object_name: str) -> None:
        """Apply AlphaFold-style confidence coloring"""
        colors = {
            "high_conf": [0.01, 0.33, 0.80],  # Dark blue
            "good_conf": [0.41, 0.79, 0.95],  # Light blue
            "med_conf": [0.99, 0.85, 0.21],   # Yellow
            "low_conf": [0.99, 0.49, 0.30],   # Orange
        }
        
        # Set custom colors
        for name, rgb in colors.items():
            cmd.set_color(name, rgb)
        
        # Apply colors based on B-factor ranges
        cmd.color("high_conf", f"{object_name} and b < 100")
        cmd.color("good_conf", f"{object_name} and b < 90")
        cmd.color("med_conf", f"{object_name} and b < 70")
        cmd.color("low_conf", f"{object_name} and b < 50")

    @staticmethod
    def create_dialog():
        """Create and configure the plugin dialog"""
        dialog = QtWidgets.QDialog()
        uifile = os.path.join(os.path.dirname(__file__), 'widget.ui')
        
        try:
            form = loadUi(uifile, dialog)
        except Exception as e:
            logger.error(f"Error loading UI file: {str(e)}")
            raise

        def fetch_uniprot():
            """Handle UniProt sequence fetch"""
            uniprot_id = form.input_uniprot_id.text().strip()
            if not uniprot_id:
                QtWidgets.QMessageBox.warning(form, "Input Error", "Please enter a UniProt ID.")
                return
                
            success, result = PyMOLfoldPlugin.fetch_uniprot_sequence(uniprot_id)
            if success:
                form.input_aa_seq.setPlainText(result)
                QtWidgets.QMessageBox.information(form, "Success", "Sequence fetched successfully!")
            else:
                QtWidgets.QMessageBox.critical(form, "Error", result)

        def run():
            """Execute structure prediction"""
            model_name = form.input_list_models.currentText()
            aa_sequence = form.input_aa_seq.toPlainText().strip()

            if not aa_sequence:
                QtWidgets.QMessageBox.warning(form, "Input Error", "Please enter an amino acid sequence.")
                return

            try:
                # Clean up existing structure
                cmd.delete("protein_ligand")
                
                # Execute appropriate folding method
                if model_name.startswith("esm3"):
                    result = PyMOLfoldPlugin.fold_esm(
                        model_name=model_name,
                        aa_sequence=aa_sequence,
                        temperature=float(form.input_esm_temp.text()),
                        num_steps=int(form.input_esm_nsteps.text()),
                        token=form.input_esm_token.text()
                    )
                elif model_name == "chai-1":
                    result = PyMOLfoldPlugin.fold_chai(
                        aa_sequence=aa_sequence,
                        ligand=form.input_boltz_ligand.toPlainText().strip(),
                        ligand_type=form.input_boltz_ligand_type.currentText() if form.input_boltz_ligand.toPlainText().strip() else None,
                        num_trunk_recycles=int(form.input_chai_recycling_steps.text()),
                        num_diffn_timesteps=int(form.input_chai_diffusion_steps.text()),
                        seed=int(form.input_chai_seed.text())
                    )
                elif model_name == "boltz-1":
                    result = PyMOLfoldPlugin.fold_boltz(
                        aa_sequence=aa_sequence,
                        ligand=form.input_boltz_ligand.toPlainText().strip(),
                        ligand_type=form.input_boltz_ligand_type.currentText() if form.input_boltz_ligand.toPlainText().strip() else None,
                        use_msa_server=form.input_boltz_use_msa_server.isChecked(),
                        recycling_steps=int(form.input_boltz_recycling_steps.text()),
                        sampling_steps=int(form.input_boltz_sampling_steps.text())
                    )
                else:
                    QtWidgets.QMessageBox.warning(
                        form, 
                        "Model Selection", 
                        f"Model {model_name} is not currently supported."
                    )
                    return

                if result.success:
                    # Load and visualize structure
                    cmd.load(result.output_path, "protein_ligand")
                    
                    # Apply coloring if requested
                    if form.input_af_coloring.isChecked():
                        PyMOLfoldPlugin.apply_alphafold_colors("protein_ligand")
                    
                    # Center view on the structure
                    cmd.zoom("protein_ligand")
                    
                    # Show success message to user
                    QtWidgets.QMessageBox.information(
                        form,
                        "Success",
                        "Structure prediction completed successfully!"
                    )
                else:
                    QtWidgets.QMessageBox.critical(
                        form,
                        "Error",
                        f"Prediction failed: {result.message}"
                    )

            except Exception as e:
                QtWidgets.QMessageBox.critical(
                    form,
                    "Error",
                    f"An unexpected error occurred: {str(e)}"
                )

        # Connect all button signals to their respective functions
        form.button_uniprot.clicked.connect(fetch_uniprot)
        form.button_fold.clicked.connect(run)
        form.button_close.clicked.connect(dialog.close)

        def update_settings_visibility():
            """Update visibility of settings groups based on selected model"""
            model = form.input_list_models.currentText()
            
            # Show/hide ESM settings
            form.esm_group.setVisible(model.startswith("esm3"))
            
            # Show/hide Boltz settings
            form.boltz_group.setVisible(model == "boltz-1")
            
            # Show/hide Chai settings
            form.chai_group.setVisible(model == "chai-1")

        # Connect model selection change to visibility update function
        form.input_list_models.currentTextChanged.connect(update_settings_visibility)
        
        # Set initial visibility state
        update_settings_visibility()

        def setup_validators():
            """Set up numeric input validators for all fields"""
            # Temperature validator (0.0 to 1.0)
            temp_validator = QtGui.QDoubleValidator(0.0, 1.0, 2)
            form.input_esm_temp.setValidator(temp_validator)

            # Steps validators (positive integers)
            steps_validator = QtGui.QIntValidator(1, 999)
            form.input_esm_nsteps.setValidator(steps_validator)
            form.input_boltz_recycling_steps.setValidator(steps_validator)
            form.input_boltz_sampling_steps.setValidator(steps_validator)
            form.input_chai_recycling_steps.setValidator(steps_validator)
            form.input_chai_diffusion_steps.setValidator(steps_validator)
            
            # Seed validator (any positive integer)
            form.input_chai_seed.setValidator(QtGui.QIntValidator(1, 999999))

        # Initialize input validators
        setup_validators()
        return dialog

def __init_plugin__(app=None):
    """Plugin entry point for PyMOL"""
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('PyMOLfold', PyMOLfoldPlugin.run_plugin_gui)

# Cleanup functionality for temporary files
@atexit.register
def cleanup_temp_files():
    """Clean up temporary files when PyMOL exits"""
    try:
        temp_dir = tempfile.gettempdir()
        for item in os.listdir(temp_dir):
            if item.startswith('pymolfold_') and (item.endswith('.pdb') or item.endswith('.cif')):
                try:
                    filepath = os.path.join(temp_dir, item)
                    if os.path.exists(filepath):
                        os.remove(filepath)
                except Exception as e:
                    logger.warning(f"Failed to remove temporary file {item}: {str(e)}")
    except Exception as e:
        logger.warning(f"Error during cleanup: {str(e)}")

# Version and attribution information
__version__ = "3.0.0"
__author__ = "Colby T. Ford, Samee Ullah"                
