from __future__ import absolute_import
from __future__ import print_function
import os, tempfile, random, string
from pathlib import Path
import torch

def __init_plugin__(app=None):
    from pymol.plugins import addmenuitemqt
    addmenuitemqt('PyMOLfold', run_plugin_gui)

dialog = None

def run_plugin_gui():
    global dialog
    if dialog is None:
        dialog = make_dialog()
    dialog.show()

def fold_esm(model_name, aa_sequence, temperature=0.7, num_steps=8, token=""):
    try:
        from esm.sdk import client
        from esm.sdk.api import ESMProtein, GenerationConfig
    except ModuleNotFoundError as e:
        raise Exception(f"esm module not found: {str(e)}")

    try:
        model = client(model=model_name, url="https://forge.evolutionaryscale.ai", token=token)
    except Exception as e:
        raise Exception(f"Error getting ESM model with token: {str(e)}")

    structure_prediction_config = GenerationConfig(
        track="structure",
        num_steps=num_steps,
        temperature=temperature,
    )
    structure_prediction_prompt = ESMProtein(sequence=aa_sequence)
    structure_prediction = model.generate(structure_prediction_prompt, structure_prediction_config)
    structure_prediction_chain = structure_prediction.to_protein_chain()
    pdb_string = structure_prediction_chain.to_pdb_string()

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdb") as temp_pdb:
        temp_pdb.write(pdb_string.encode())
        temp_pdb_path = temp_pdb.name

    return temp_pdb_path

def fold_chai(aa_sequence, ligand=None, ligand_type=None, num_trunk_recycles=3, num_diffn_timesteps=200, seed=1337):
    try:
        from chai_lab.chai1 import run_inference
        from pymol import cmd
    except ImportError as e:
        raise Exception(f"Could not import required module: {str(e)}")

    base_dir = Path(tempfile.mkdtemp())
    input_dir = base_dir / "input"
    output_dir = base_dir / "output"
    input_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)

    if ligand and ligand_type:
        if ligand_type == "smiles":
            fasta_content = ">protein|name=chain_A\n{}\n>ligand|name=chain_B\n{}\n".format(
                aa_sequence.strip(), ligand.strip()
            )
        elif ligand_type == "ccd":
            fasta_content = ">protein|name=chain_A\n{}\n>ligand|name=chain_B\n{}\n".format(
                aa_sequence.strip(), ligand.strip()
            )
    else:
        fasta_content = ">protein|name=chain_A\n{}\n".format(aa_sequence.strip())

    fasta_path = input_dir / "sequence.fasta"
    fasta_path.write_text(fasta_content)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    
    candidates = run_inference(
        fasta_file=fasta_path,
        output_dir=output_dir,
        num_trunk_recycles=num_trunk_recycles,
        num_diffn_timesteps=num_diffn_timesteps,
        seed=seed,
        device=device,
        use_esm_embeddings=True
    )

    if not candidates.cif_paths:
        raise ValueError("No structure files were generated")

    output_path = str(candidates.cif_paths[0])
    cmd.delete("protein_ligand")
    cmd.load(output_path, "protein_ligand", format="cif", state=1)
    
    return output_path

def fold_boltz(aa_sequence, ligand=None, ligand_type=None, use_msa_server=False, recycling_steps=3, sampling_steps=200):
    try:
        import boltz
        import torch
        import subprocess
        import sys
    except ModuleNotFoundError as e:
        raise Exception(f"Required module not found: {str(e)}")

    base_dir = Path(tempfile.mkdtemp())
    input_dir = base_dir / "input"
    output_dir = base_dir / "output"
    input_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)

    fasta_content = f">A|protein|empty\n{aa_sequence}\n"
    if ligand and ligand_type:
        if ligand_type == "ccd":
            fasta_content += f">B|ccd|\n{ligand}\n"
        elif ligand_type == "smiles":
            fasta_content += f">B|smiles|\n{ligand}\n"

    fasta_path = input_dir / "sequence.fasta"
    fasta_path.write_text(fasta_content)
    
    device = "gpu" if torch.cuda.is_available() else "cpu"
    
    try:
        boltz_cmd = Path(sys.executable).parent / 'boltz'
        cmd = [
            str(boltz_cmd),
            "predict",
            str(fasta_path),
            "--out_dir", str(output_dir),
            "--accelerator", device,
            "--output_format", "pdb",
            "--recycling_steps", str(recycling_steps),
            "--sampling_steps", str(sampling_steps)
        ]
        
        if use_msa_server:
            cmd.append("--use_msa_server")
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
    except Exception as e:
        raise Exception(f"Error during structure prediction: {str(e)}")
    
    output_path = output_dir / "boltz_results_sequence" / "predictions" / "sequence" / "sequence_model_0.pdb"
    if not output_path.exists():
        raise FileNotFoundError(f"Expected output file not found at: {output_path}")
        
    return str(output_path)

def apply_alphafold_colors(object_name):
    from pymol import cmd
    
    cmd.set_color("n0", [0.051, 0.341, 0.827])
    cmd.set_color("n1", [0.416, 0.796, 0.945])
    cmd.set_color("n2", [0.996, 0.851, 0.212])
    cmd.set_color("n3", [0.992, 0.490, 0.302])
    
    cmd.color("n0", f"{object_name} and b < 100")
    cmd.color("n1", f"{object_name} and b < 90")
    cmd.color("n2", f"{object_name} and b < 70")
    cmd.color("n3", f"{object_name} and b < 50")

def make_dialog():
    from pymol import cmd
    from pymol.Qt import QtWidgets
    from pymol.Qt.utils import loadUi

    dialog = QtWidgets.QDialog()
    uifile = os.path.join(os.path.dirname(__file__), 'widget.ui')
    form = loadUi(uifile, dialog)

    def run():
        model_name = form.input_list_models.currentText()
        aa_sequence = form.input_aa_seq.toPlainText().strip()
        af_coloring = form.input_af_coloring.isChecked()

        if not aa_sequence:
            QtWidgets.QMessageBox.warning(form, "Error", "Please enter a valid amino acid sequence.")
            return

        try:
            cmd.delete("protein_ligand")  # Clean up existing objects
            
            if model_name.startswith("esm3"):
                folded_pdb_path = fold_esm(
                    model_name,
                    aa_sequence,
                    temperature=float(form.input_esm_temp.text()),
                    num_steps=int(form.input_esm_nsteps.text()),
                    token=form.input_esm_token.text()
                )
                cmd.load(folded_pdb_path, "protein_ligand")
                
            elif model_name == "chai-1":
                folded_pdb_path = fold_chai(
                    aa_sequence,
                    ligand=form.input_boltz_ligand.toPlainText().strip(),
                    ligand_type=form.input_boltz_ligand_type.currentText() if form.input_boltz_ligand.toPlainText().strip() else None,
                    num_trunk_recycles=int(form.input_chai_recycling_steps.text()),
                    num_diffn_timesteps=int(form.input_chai_diffusion_steps.text()),
                    seed=int(form.input_chai_seed.text())
                )
                
            elif model_name == "boltz-1":
                folded_pdb_path = fold_boltz(
                    aa_sequence,
                    ligand=form.input_boltz_ligand.toPlainText().strip(),
                    ligand_type=form.input_boltz_ligand_type.currentText() if form.input_boltz_ligand.toPlainText().strip() else None,
                    use_msa_server=form.input_boltz_use_msa_server.isChecked(),
                    recycling_steps=int(form.input_boltz_recycling_steps.text()),
                    sampling_steps=int(form.input_boltz_sampling_steps.text())
                )
                cmd.load(folded_pdb_path, "protein_ligand")
            else:
                QtWidgets.QMessageBox.critical(form, "Error", f"Not a supported model name: {str(model_name)}")
                return
            
            if af_coloring:
                apply_alphafold_colors("protein_ligand")
            
            QtWidgets.QMessageBox.information(form, "Success", "Structure folded and loaded into PyMOL!")
        
        except Exception as e:
            QtWidgets.QMessageBox.critical(form, "Error", f"An error occurred: {str(e)}")

    form.button_fold.clicked.connect(run)
    form.button_close.clicked.connect(dialog.close)

    return dialog
